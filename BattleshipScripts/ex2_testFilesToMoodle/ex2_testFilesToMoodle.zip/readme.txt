Add you dlls to the folders:
Game1: don't add
Game2: Naive & File
Game3: Smart & Naive

note: The *.attack files are not always necessary but they are there for sanity check